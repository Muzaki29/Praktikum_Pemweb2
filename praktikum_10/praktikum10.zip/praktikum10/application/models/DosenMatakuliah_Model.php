<?php
class MatakuliahDosen_Model extends CI_Model
{
    public $id, $nama_matkul, $kode;
} 